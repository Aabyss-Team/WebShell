<?php echo "Exec privs on ".$_SERVER["PHP_SELF"]; ?>
