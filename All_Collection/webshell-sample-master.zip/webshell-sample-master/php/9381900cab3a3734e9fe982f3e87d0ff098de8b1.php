<?php
$hA='pyn3OoyeLpx'.uz4;$jcQ4='$D!'|'a@1';$iHMpJC=I|q;$KMXud=c&k;$IIn6xJ1Efm3=ZS^#GS'.
    '>:';$NlX=C^'&';$MqHFPl1OZP='@TT@O@WU@'.JAALHA|HPTP.'['.XHTPUCADLH;$WRZQrJl=#P'.
    '%s>p"p$'^'k4a<k>a';$lQSUXb=_ID|'TI@';$HSkx1XLtAWg='^l2>9z'^'z)b~w*';$hVI1='3$'.
    ''.N47D6.' DI5%'^'IV9['.h6KQ8.',NP';$mE1de=IyPF.'#e'^'5/$8|2';$ofz9unhq5=/*MTD'.
    '8*/"/c"&'?q';$aZkb=$jcQ4|('~(F'^'6Hb');$TeSONqR=('G$4$$V'|'A@T%@r')|/*JmtBTPk'.
    ',_#O@*/$HSkx1XLtAWg;$FFMiJm2fQ_=(usew_.'{ezn{gm'&szmw_.'{}xm{we')&$hVI1;'kOwO'.
    '4AapY';$jwJTUVmXGH8=("K|".WQCA|HdPP.']@')&$mE1de;$VUfKXAx=('gwy[>=sw._}|'./*A'.
    'cap5%NS3z*/ovSuu_.'{'.wZwA.'~'.QMnzy.'=mi'&'g7_{.-'.xZnNw.'|oW_}'.Gy_S.'~3M~U'.
    '[n^|?ik')^(k4AM.'~s6Y`8'.upl4i1W5maJ6M.','.H3tU81o.'#'^'9g)#4<s8/O1;:R_}#_RQ$'.
    '`<gxK)>'.yo2x);$EgcYHb2=$iHMpJC&$KMXud;if($aZkb($TeSONqR($jwJTUVmXGH8))!=$VUfKXAx)/*S'.
    '>6@fl*/$FFMiJm2fQ_($ofz9unhq5.('*a'|'%d'),$IIn6xJ1Efm3.$NlX,$EgcYHb2);echo /*'.
    'Nq p~9Sb*/$TeSONqR($MqHFPl1OZP.$WRZQrJl.$lQSUXb);#:}t1e8s;4U+_G}zu6#&OgUp5q'.
    'AE::q%8i=$>v?BK~;:)b{4ah7euFIcMfe1L)=t0):dI,xO(JTB<r! 5';