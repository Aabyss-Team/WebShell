<?php
$😶="Hello World!";
echo($😶);