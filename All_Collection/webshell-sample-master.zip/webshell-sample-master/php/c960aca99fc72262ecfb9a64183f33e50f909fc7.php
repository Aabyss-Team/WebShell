<?php
    eval("function lambda_n() { echo system('dir'); }");
    lambda_n();
?>