<?php
	$filename=$_GET['xbid'];
	include ($filename);
?>